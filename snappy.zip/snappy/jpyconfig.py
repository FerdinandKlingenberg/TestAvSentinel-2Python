# Created by 'jpyutil.py' tool on 2017-07-25 06:54:27.240756
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = '/home/fklingenberg/snap/jre'
jvm_dll = '/home/fklingenberg/snap/jre/lib/amd64/server/libjvm.so'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
